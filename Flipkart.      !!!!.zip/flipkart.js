 function login() {
         alert("Are you sure for login");
         document.getElementById('login').style.display = "block";

 }